export default {
    breakpoint: new CustomEvent('breakpoint.fc'),
    pageChanged: new CustomEvent('pageChanged.fc'),
    pageChanging: new CustomEvent('pageChanging.fc'),
};
