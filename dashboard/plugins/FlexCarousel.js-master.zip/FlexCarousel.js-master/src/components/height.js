export default function (fc) {
    if (fc._options.height) {
        fc._selector.style.height = fc._options.height;
    }
}
